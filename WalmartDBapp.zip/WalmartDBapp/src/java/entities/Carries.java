/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dillon
 */
@Entity
@Table(name = "carries")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Carries.findAll", query = "SELECT c FROM Carries c"),
    @NamedQuery(name = "Carries.findByStoreIDc", query = "SELECT c FROM Carries c WHERE c.carriesPK.storeIDc = :storeIDc"),
    @NamedQuery(name = "Carries.findByProductIDc", query = "SELECT c FROM Carries c WHERE c.carriesPK.productIDc = :productIDc"),
    @NamedQuery(name = "Carries.findByQuantityc", query = "SELECT c FROM Carries c WHERE c.quantityc = :quantityc"),
    @NamedQuery(name = "Carries.findByPricec", query = "SELECT c FROM Carries c WHERE c.pricec = :pricec")})
public class Carries implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected CarriesPK carriesPK;
    @Column(name = "Quantityc")
    private Integer quantityc;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "Pricec")
    private Float pricec;
    @JoinColumn(name = "ProductIDc", referencedColumnName = "Pid", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Product product;
    @JoinColumn(name = "StoreIDc", referencedColumnName = "Sid", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Store store;

    public Carries() {
    }

    public Carries(CarriesPK carriesPK) {
        this.carriesPK = carriesPK;
    }

    public Carries(int storeIDc, int productIDc) {
        this.carriesPK = new CarriesPK(storeIDc, productIDc);
    }

    public CarriesPK getCarriesPK() {
        return carriesPK;
    }

    public void setCarriesPK(CarriesPK carriesPK) {
        this.carriesPK = carriesPK;
    }

    public Integer getQuantityc() {
        return quantityc;
    }

    public void setQuantityc(Integer quantityc) {
        this.quantityc = quantityc;
    }

    public Float getPricec() {
        return pricec;
    }

    public void setPricec(Float pricec) {
        this.pricec = pricec;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (carriesPK != null ? carriesPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Carries)) {
            return false;
        }
        Carries other = (Carries) object;
        if ((this.carriesPK == null && other.carriesPK != null) || (this.carriesPK != null && !this.carriesPK.equals(other.carriesPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Carries[ carriesPK=" + carriesPK + " ]";
    }
    
}
