/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Dillon
 */
@Entity
@Table(name = "warehouse")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Warehouse.findAll", query = "SELECT w FROM Warehouse w"),
    @NamedQuery(name = "Warehouse.findByWarehouseID", query = "SELECT w FROM Warehouse w WHERE w.warehouseID = :warehouseID"),
    @NamedQuery(name = "Warehouse.findByAddress", query = "SELECT w FROM Warehouse w WHERE w.address = :address")})
public class Warehouse implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "WarehouseID")
    private Integer warehouseID;
    @Size(max = 45)
    @Column(name = "Address")
    private String address;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "warehouse")
    private Collection<Ordersfrom> ordersfromCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "warehouse")
    private Collection<Supplies> suppliesCollection;
    @OneToMany(mappedBy = "primaryWarehouse")
    private Collection<Vendor> vendorCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "warehouse")
    private Collection<Receives> receivesCollection;
    @OneToMany(mappedBy = "pwarehouse")
    private Collection<Store> storeCollection;
    @OneToMany(mappedBy = "warehouseID")
    private Collection<Employee> employeeCollection;
    @JoinColumn(name = "ManagerID", referencedColumnName = "SSN")
    @ManyToOne
    private Employee managerID;

    public Warehouse() {
    }

    public Warehouse(Integer warehouseID) {
        this.warehouseID = warehouseID;
    }

    public Integer getWarehouseID() {
        return warehouseID;
    }

    public void setWarehouseID(Integer warehouseID) {
        this.warehouseID = warehouseID;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @XmlTransient
    public Collection<Ordersfrom> getOrdersfromCollection() {
        return ordersfromCollection;
    }

    public void setOrdersfromCollection(Collection<Ordersfrom> ordersfromCollection) {
        this.ordersfromCollection = ordersfromCollection;
    }

    @XmlTransient
    public Collection<Supplies> getSuppliesCollection() {
        return suppliesCollection;
    }

    public void setSuppliesCollection(Collection<Supplies> suppliesCollection) {
        this.suppliesCollection = suppliesCollection;
    }

    @XmlTransient
    public Collection<Vendor> getVendorCollection() {
        return vendorCollection;
    }

    public void setVendorCollection(Collection<Vendor> vendorCollection) {
        this.vendorCollection = vendorCollection;
    }

    @XmlTransient
    public Collection<Receives> getReceivesCollection() {
        return receivesCollection;
    }

    public void setReceivesCollection(Collection<Receives> receivesCollection) {
        this.receivesCollection = receivesCollection;
    }

    @XmlTransient
    public Collection<Store> getStoreCollection() {
        return storeCollection;
    }

    public void setStoreCollection(Collection<Store> storeCollection) {
        this.storeCollection = storeCollection;
    }

    @XmlTransient
    public Collection<Employee> getEmployeeCollection() {
        return employeeCollection;
    }

    public void setEmployeeCollection(Collection<Employee> employeeCollection) {
        this.employeeCollection = employeeCollection;
    }

    public Employee getManagerID() {
        return managerID;
    }

    public void setManagerID(Employee managerID) {
        this.managerID = managerID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (warehouseID != null ? warehouseID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Warehouse)) {
            return false;
        }
        Warehouse other = (Warehouse) object;
        if ((this.warehouseID == null && other.warehouseID != null) || (this.warehouseID != null && !this.warehouseID.equals(other.warehouseID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Warehouse[ warehouseID=" + warehouseID + " ]";
    }
    
}
