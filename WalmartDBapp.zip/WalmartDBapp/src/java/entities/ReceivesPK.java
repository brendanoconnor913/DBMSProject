/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Dillon
 */
@Embeddable
public class ReceivesPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "WarehID")
    private int warehID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "ProID")
    private int proID;

    public ReceivesPK() {
    }

    public ReceivesPK(int warehID, int proID) {
        this.warehID = warehID;
        this.proID = proID;
    }

    public int getWarehID() {
        return warehID;
    }

    public void setWarehID(int warehID) {
        this.warehID = warehID;
    }

    public int getProID() {
        return proID;
    }

    public void setProID(int proID) {
        this.proID = proID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) warehID;
        hash += (int) proID;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof ReceivesPK)) {
            return false;
        }
        ReceivesPK other = (ReceivesPK) object;
        if (this.warehID != other.warehID) {
            return false;
        }
        if (this.proID != other.proID) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.ReceivesPK[ warehID=" + warehID + ", proID=" + proID + " ]";
    }
    
}
