/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import java.util.Iterator;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import entities.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
/**
 *
 * @author Dillon
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class TransactionManager {
    @PersistenceContext(unitName = "WalmartDBappPU")
    private EntityManager em;
    @Resource
    private SessionContext context;
  
    
    
    
    
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addEmployee(Integer Essn, String Eaddress, String Edob, String Ename, String Ephone, String Esalary, String EstartDate) {
        Employee newEmployee = new Employee();
        newEmployee.setSsn(Essn);
        newEmployee.setAddress(Eaddress);
        newEmployee.setDoB(Edob);
        newEmployee.setName(Ename);
        newEmployee.setPhone(Ephone);
        newEmployee.setSalary(Esalary);
        newEmployee.setStartDate(EstartDate);

        em.persist(newEmployee);
       
    }
    
    public void addWarehouse(Integer wID, String wAddress) {
        Warehouse newWarehouse = new Warehouse();
        newWarehouse.setWarehouseID(wID);
        newWarehouse.setAddress(wAddress);
        em.persist(newWarehouse);
    }
    public List getEmpID(Integer eID) {
        TypedQuery<Employee> query = em.createQuery("SELECT c FROM Employee c WHERE c.ssn = '" + eID + "' ", Employee.class);
        List<Employee> results = query.getResultList();
        return (List<Employee>) results;
    } 

    public void hireWarehouseEmployee(Integer wID, Integer eID) {
        Warehouse warehouse = em.find(Warehouse.class, wID);
        Employee employee = em.find(Employee.class, eID);
        employee.setWarehouseID(warehouse);
        warehouse.setManagerID(employee);
    }
    public void fireEmployee(Integer eID) { 
        Employee employee = em.find(Employee.class, eID);
        if(employee.getStoreID() == null){
            Warehouse warehouse = em.find(Warehouse.class, employee.getWarehouseID().getWarehouseID());
            employee.setWarehouseID(null);
            employee.setStoreID(null);
            warehouse.setManagerID(null);
        }else{
            Store store = em.find(Store.class, employee.getStoreID().getSid());
            employee.setWarehouseID(null);
            employee.setStoreID(null);
            store.setMngSSN(null);
        }    
//        employee.setWarehouseID(null);
//        employee.setStoreID(null);
//        warehouse.setManagerID(null);
        
    }
    
    public void hireStoreEmployee(Integer sID, Integer eID) {
        Store store = em.find(Store.class, sID);
        Employee employee = em.find(Employee.class, eID);
        employee.setStoreID(store);
        store.setMngSSN(employee);
    }
    public void addStore(Integer sID, String sAddress) {
        Store newStore = new Store();
        newStore.setSid(sID);
        newStore.setAddress(sAddress);
        em.persist(newStore);
    }
    
}
