/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.*;
import javax.persistence.EntityManager;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import session.CarriesFacade;
import session.EmployeeFacade;
import session.TransactionManager;
import session.OrdersfromFacade;
import session.ProductFacade;
import session.ReceivesFacade;
import session.StoreFacade;
import session.SuppliesFacade;
import session.VendorFacade;
import session.WarehouseFacade;

/**
 *
 * @author Dillon
 */
@WebServlet(name = "/ControllerServlet", loadOnStartup = 1, urlPatterns = {"/ControllerServlet", "/index", "/Warehouse", "/hireEmployee"})
public class ControllerServlet extends HttpServlet {
    @EJB
    private CarriesFacade carriesFacades;
    @EJB
    private EmployeeFacade employeesFacades;
    @EJB
    private OrdersfromFacade ordersFromFacades;
    @EJB
    private ProductFacade productsFacades;
    @EJB
    private ReceivesFacade receivesFacades;
    @EJB
    private StoreFacade storesFacades;
    @EJB
    private SuppliesFacade suppliesFacades;
    @EJB
    private VendorFacade vendorsFacades;
    @EJB
    private WarehouseFacade warehousesFacades;
    @EJB
    private TransactionManager transactionsManager;
     
    @Override
    public void init() throws ServletException {
    
            
        // store category list in servlet context
       getServletContext().setAttribute("employees", employeesFacades.findAll());
       getServletContext().setAttribute("warehouses", warehousesFacades.findAll());
       getServletContext().setAttribute("stores", storesFacades.findAll());
       
       //getServletContext().setAttribute("customerNameInput", customerFacade.findByRfcrffNameInput(nameID));
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        
        String userPath = request.getServletPath();
        HttpSession session = request.getSession();
         session.setAttribute("employees", employeesFacades.findAll());
        
        if (request.getParameter("addEmployee") != null) {
            Integer eSSN = Integer.parseInt(request.getParameter("empSSN"));
            String eStartD = request.getParameter("empStartDate");
            String eName = request.getParameter("empName");
            String ePhone = request.getParameter("empPhone");
            String eSalary = request.getParameter("empSalary");
            String eAddress = request.getParameter("empAddress");
            String eDoB = request.getParameter("empDoB");
            
            transactionsManager.addEmployee(eSSN, eAddress, eDoB, eName, ePhone, eSalary, eStartD);
            
            userPath = "index";
        
        } 
        else if (request.getParameter("addWarehouse") != null) {
            Integer wID = Integer.parseInt(request.getParameter("wareID"));
            String wAddress = request.getParameter("wareAddress");

            transactionsManager.addWarehouse(wID, wAddress);
            
            userPath = "Warehouse";
        } 
        else if (request.getParameter("addStore") != null) {
            Integer sID = Integer.parseInt(request.getParameter("storeID"));
            String sAddress = request.getParameter("storeAddress");

            transactionsManager.addStore(sID, sAddress);
            
            userPath = "Store";
        } 
        
        
        
        
        
        else if (request.getParameter("hireEmpButton") != null) {   
            int selectedEmployeeSSN, storeID, warehouseID;
            String selector;
            
            selectedEmployeeSSN = Integer.parseInt(request.getParameter("empSSNselector"));
            
            
            if(request.getParameter("hireSelectDropdown")!=null)
            {
                selector = request.getParameter("hireSelectDropdown");

                if("Warehouse".equals(selector)){
                    warehouseID = Integer.parseInt(request.getParameter("inputID"));
                    transactionsManager.hireWarehouseEmployee(warehouseID, selectedEmployeeSSN);

                } else if ("Store".equals(selector)){
                    storeID = Integer.parseInt(request.getParameter("inputID"));
                    transactionsManager.hireStoreEmployee(storeID, selectedEmployeeSSN);

                }
                userPath = "hireEmployee";
            }  
            
        }
        else if (request.getParameter("fireEmpButton") != null) {   
            int selectedEmployeeSSN;
            
            selectedEmployeeSSN = Integer.parseInt(request.getParameter("empSSNselector"));
            transactionsManager.fireEmployee(selectedEmployeeSSN);
 
                userPath = "fireEmployee";

        }
        
        
        else if (request.getParameter("empTableRefresh") != null) {
            session.setAttribute("employees", employeesFacades.findAll());
            userPath = "index";
        }
        else if (request.getParameter("warTableRefresh") != null) {
            session.setAttribute("warehouses", warehousesFacades.findAll());
            userPath = "Warehouse";
        }
        else if (request.getParameter("storeTableRefresh") != null) {
            session.setAttribute("stores", storesFacades.findAll());
            userPath = "Store";
        }
        else if (request.getParameter("hireTableRefresh") != null) {
            session.setAttribute("employees", employeesFacades.findAll());
            userPath = "hireEmployee";
        }
        else if (request.getParameter("fireTableRefresh") != null) {
            session.setAttribute("employees", employeesFacades.findAll());
            userPath = "fireEmployee";
        }
      
        
        
        
        
        
        
        
        
        
        
        
        
       String url = userPath + ".jsp";

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
   

}
