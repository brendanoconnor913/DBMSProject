/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package session;

import java.util.Iterator;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;
import entities.*;
import static entities.Receives_.receivesPK;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.SessionContext;
import javax.ejb.Stateless;
import javax.ejb.TransactionAttribute;
import javax.ejb.TransactionAttributeType;
import javax.ejb.TransactionManagement;
import javax.ejb.TransactionManagementType;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
/**
 *
 * @author Dillon
 */
@Stateless
@TransactionManagement(TransactionManagementType.CONTAINER)
public class TransactionManager {
    @PersistenceContext(unitName = "WalmartDBappPU")
    private EntityManager em;
    @Resource
    private SessionContext context;
  
    
    
    
    
    @TransactionAttribute(TransactionAttributeType.REQUIRED)
    public void addEmployee(Integer Essn, String Eaddress, String Edob, String Ename, String Ephone, String Esalary, String EstartDate) {
        Employee newEmployee = new Employee();
        newEmployee.setSsn(Essn);
        newEmployee.setAddress(Eaddress);
        newEmployee.setDoB(Edob);
        newEmployee.setName(Ename);
        newEmployee.setPhone(Ephone);
        newEmployee.setSalary(Esalary);
        newEmployee.setStartDate(EstartDate);

        em.persist(newEmployee);
       
    }
    
    public void addWarehouse(Integer wID, String wAddress) {
        Warehouse newWarehouse = new Warehouse();
        newWarehouse.setWarehouseID(wID);
        newWarehouse.setAddress(wAddress);
        em.persist(newWarehouse);
    }
    
    public List getEmpID(Integer eID) {
        TypedQuery<Employee> query = em.createQuery("SELECT c FROM Employee c WHERE c.ssn = '" + eID + "' ", Employee.class);
        List<Employee> results = query.getResultList();
        return (List<Employee>) results;
    } 

    public void hireWarehouseEmployee(Integer wID, Integer eID) {
        Warehouse warehouse = em.find(Warehouse.class, wID);
        Employee employee = em.find(Employee.class, eID);
        employee.setWarehouseID(warehouse);
        warehouse.setManagerID(employee);
    }
    
    public void fireEmployee(Integer eID) { 
        Employee employee = em.find(Employee.class, eID);
        if(employee.getStoreID() == null){
            Warehouse warehouse = em.find(Warehouse.class, employee.getWarehouseID().getWarehouseID());
            employee.setWarehouseID(null);
            employee.setStoreID(null);
            warehouse.setManagerID(null);
        }else{
            Store store = em.find(Store.class, employee.getStoreID().getSid());
            employee.setWarehouseID(null);
            employee.setStoreID(null);
            store.setMngSSN(null);
        }    
    }
    
    public void addWarehouseInventory(Integer sID, Integer eID) {
        Store store = em.find(Store.class, sID);
        Employee employee = em.find(Employee.class, eID);
        employee.setStoreID(store);
        store.setMngSSN(employee);
    }  
    
    public void hireStoreEmployee(Integer sID, Integer eID) {
        Store store = em.find(Store.class, sID);
        Employee employee = em.find(Employee.class, eID);
        employee.setStoreID(store);
        store.setMngSSN(employee);
    }
    
    public void addStore(Integer sID, String sAddress) {
        Store newStore = new Store();
        newStore.setSid(sID);
        newStore.setAddress(sAddress);
        em.persist(newStore);
    }
    
    public void addVendor(Integer vID,String vName, String vAddress) {
        Vendor newVendor = new Vendor();
        newVendor.setVid(vID);
        newVendor.setVname(vName);
        newVendor.setAddress(vAddress);
        em.persist(newVendor);
    }
    
    public void addProduct(Integer pID, String pName) {
        Product newProduct = new Product();
        newProduct.setPid(pID);
        newProduct.setPname(pName);
        em.persist(newProduct);
    }   
    
    public void orderFromVendorToWarehouse(Integer wID, Integer vID, Integer pID, Integer pQuantity) {
        Warehouse warehouse = em.find(Warehouse.class, wID);
        Product product = em.find(Product.class, pID);
        Vendor vendor = em.find(Vendor.class, vID);
        ReceivesPK receivepk = new ReceivesPK();
        receivepk.setProID(pID);
        receivepk.setWarehID(wID);
        
        SellsPK sellspk = new SellsPK();
        sellspk.setProductID(pID);
        sellspk.setVenID(vID);
        
        Receives receive = em.find(Receives.class, receivepk);
        if(receive == null){
            receive = new Receives();
            receive.setProduct(product);
            receive.setQuantity(pQuantity);
            receive.setWarehouse(warehouse);
            receive.setReceivesPK(receivepk);
        } else{

        receive.setProduct(product);
        receive.setQuantity(receive.getQuantity() + pQuantity);
        receive.setWarehouse(warehouse);
        receive.setReceivesPK(receivepk);
        }
        em.persist(receive);
        
        Sells sells= em.find(Sells.class, sellspk);
        if(sells == null){
            sells = new Sells();
            sells.setProduct(product);
            sells.setQuantityProd(pQuantity);
            sells.setVendor(vendor);
            sells.setSellsPK(sellspk);
        }
        else{
            sells.setProduct(product);
            sells.setQuantityProd(sells.getQuantityProd() - pQuantity);
            sells.setVendor(vendor);
            sells.setSellsPK(sellspk);
        }
        em.persist(sells);
        
    }
    
        public void addVendorInventory(Integer vID, Integer pID, Integer pQuantity) {
        Vendor vendor = em.find(Vendor.class, vID);
        Product product = em.find(Product.class, pID);
        SellsPK sellsPK = new SellsPK();
        sellsPK.setProductID(pID);
        sellsPK.setVenID(vID);
        Sells sells = em.find(Sells.class, sellsPK);
        if(sells == null){
            sells = new Sells();
            sells.setProduct(product);
            sells.setQuantityProd(pQuantity);
            sells.setVendor(vendor);
            sells.setSellsPK(sellsPK);
        } else{

        sells.setProduct(product);
        sells.setQuantityProd(sells.getQuantityProd() + pQuantity);
        sells.setVendor(vendor);
        sells.setSellsPK(sellsPK);
        }
        em.persist(sells);
    }
    
    public void orderFromWarehouseToStore(Integer wID,Integer sID, Integer pID, Integer pQuantity) {
        Warehouse warehouse = em.find(Warehouse.class, wID);
        Product product = em.find(Product.class, pID);
        Store store = em.find(Store.class, sID);
        CarriesPK carriesPK = new CarriesPK();
        carriesPK.setProductIDc(pID);
        carriesPK.setStoreIDc(sID);
        Carries carries = em.find(Carries.class, carriesPK);
        if(carries == null){
            carries = new Carries();
            carries.setProduct(product);
            carries.setQuantityc(pQuantity);
            carries.setStore(store);
            carries.setCarriesPK(carriesPK);
        } else{

        carries.setProduct(product);
        carries.setQuantityc(carries.getQuantityc() + pQuantity);
        carries.setStore(store);
        carries.setCarriesPK(carriesPK);
        }
        em.persist(carries);


        ReceivesPK receivepk = new ReceivesPK();
        receivepk.setProID(pID);
        receivepk.setWarehID(wID);

        Receives receive = em.find(Receives.class, receivepk);

        receive.setQuantity(receive.getQuantity() - pQuantity);

        em.persist(receive);
    }
    
}
