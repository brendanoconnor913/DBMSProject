/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import entities.*;
import javax.persistence.EntityManager;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.io.PrintWriter;
import javax.ejb.EJB;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import session.*;


/**
 *
 * @author Dillon
 */
@WebServlet(name = "/ControllerServlet", loadOnStartup = 1, urlPatterns = {"/ControllerServlet", "/index", "/Warehouse", "/Vendor", "/VendorInventory", "/hireEmployee", "/Product", "/WarehouseInventory"})
public class ControllerServlet extends HttpServlet {
    @EJB
    private CarriesFacade carriesFacades;
    @EJB
    private EmployeeFacade employeesFacades;
    @EJB
    private OrdersfromFacade ordersFromFacades;
    @EJB
    private ProductFacade productsFacades;
    @EJB
    private ReceivesFacade receivesFacades;
    @EJB
    private StoreFacade storesFacades;
    @EJB
    private SuppliesFacade suppliesFacades;
    @EJB
    private VendorFacade vendorsFacades;
    @EJB
    private WarehouseFacade warehousesFacades;
    @EJB
    private TransactionManager transactionsManager;
    @EJB
    private SellsFacade sellsFacade;
     
    @Override
    public void init() throws ServletException {
    
            
        // store category list in servlet context
       getServletContext().setAttribute("employees", employeesFacades.findAll());
       getServletContext().setAttribute("warehouses", warehousesFacades.findAll());
       getServletContext().setAttribute("product", productsFacades.findAll());
       getServletContext().setAttribute("recievesTable", receivesFacades.findAll());
       getServletContext().setAttribute("storeCarriesTable", carriesFacades.findAll());
       getServletContext().setAttribute("ordersFrom", ordersFromFacades.findAll());
       getServletContext().setAttribute("vendors", vendorsFacades.findAll());
       getServletContext().setAttribute("sells", sellsFacade.findAll());
       getServletContext().setAttribute("stores", storesFacades.findAll());
      
       //getServletContext().setAttribute("customerNameInput", customerFacade.findByRfcrffNameInput(nameID));
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
        
        String userPath = request.getServletPath();
        HttpSession session = request.getSession();
         session.setAttribute("employees", employeesFacades.findAll());
        
        if (request.getParameter("addEmployee") != null) {
            Integer eSSN = Integer.parseInt(request.getParameter("empSSN"));
            String eStartD = request.getParameter("empStartDate");
            String eName = request.getParameter("empName");
            String ePhone = request.getParameter("empPhone");
            String eSalary = request.getParameter("empSalary");
            String eAddress = request.getParameter("empAddress");
            String eDoB = request.getParameter("empDoB");
            
            transactionsManager.addEmployee(eSSN, eAddress, eDoB, eName, ePhone, eSalary, eStartD);
            
            userPath = "index";
        
        } 
        else if (request.getParameter("addWarehouse") != null) {
            Integer wID = Integer.parseInt(request.getParameter("wareID"));
            String wAddress = request.getParameter("wareAddress");

            transactionsManager.addWarehouse(wID, wAddress);
            
            userPath = "Warehouse";
        } 
        else if (request.getParameter("addStore") != null) {
            Integer sID = Integer.parseInt(request.getParameter("storeID"));
            String sAddress = request.getParameter("storeAddress");

            transactionsManager.addStore(sID, sAddress);
            
            userPath = "Store";
        } 
        else if (request.getParameter("addProduct") != null) {
            Integer pID = Integer.parseInt(request.getParameter("productID"));
            String pName = request.getParameter("productName");

            transactionsManager.addProduct(pID, pName);
            
            userPath = "Product";
        }      
        else if (request.getParameter("addVendorInventory") != null) {   
            int vendorID = Integer.parseInt(request.getParameter("vendorID"));
            int productID = Integer.parseInt(request.getParameter("productID"));
            int prodQuantity = Integer.parseInt(request.getParameter("quantityOfProduct"));
                    
            transactionsManager.addVendorInventory(vendorID,productID,prodQuantity);
 
                userPath = "VendorInventory";
        }
        
        
        
        else if (request.getParameter("hireEmpButton") != null) {   
            int selectedEmployeeSSN, storeID, warehouseID;
            String selector;
            
            selectedEmployeeSSN = Integer.parseInt(request.getParameter("empSSNselector"));
            
            
            if(request.getParameter("hireSelectDropdown")!=null)
            {
                selector = request.getParameter("hireSelectDropdown");

                if("Warehouse".equals(selector)){
                    warehouseID = Integer.parseInt(request.getParameter("inputID"));
                    transactionsManager.hireWarehouseEmployee(warehouseID, selectedEmployeeSSN);

                } else if ("Store".equals(selector)){
                    storeID = Integer.parseInt(request.getParameter("inputID"));
                    transactionsManager.hireStoreEmployee(storeID, selectedEmployeeSSN);

                }
                userPath = "hireEmployee";
            }  
            
        }
        else if (request.getParameter("fireEmpButton") != null) {   
            int selectedEmployeeSSN;
            
            selectedEmployeeSSN = Integer.parseInt(request.getParameter("empSSNselector"));
            transactionsManager.fireEmployee(selectedEmployeeSSN);
 
                userPath = "fireEmployee";

        }
        else if (request.getParameter("addProduct") != null) {   
            int selectedCarriesID = Integer.parseInt(request.getParameter("storeIDdropdown"));

            transactionsManager.fireEmployee(selectedCarriesID);
 
                userPath = "Product";

        }
        else if (request.getParameter("addWarehouseInventory") != null) {   
            int warehouseID = Integer.parseInt(request.getParameter("warehouseID"));
            int vendorID = Integer.parseInt(request.getParameter("vendorID"));
            int productID = Integer.parseInt(request.getParameter("productID"));
            int prodQuantity = Integer.parseInt(request.getParameter("quantityOfProduct"));
                    
            transactionsManager.orderFromVendorToWarehouse(warehouseID, vendorID, productID, prodQuantity);
 
                userPath = "WarehouseInventory";
        }
        else if (request.getParameter("orderFromWarehouseInventory") != null) {   
            int warehouseID = Integer.parseInt(request.getParameter("warehouseID"));
            int storeID = Integer.parseInt(request.getParameter("storeID"));
            int productID = Integer.parseInt(request.getParameter("productID"));
            int prodQuantity = Integer.parseInt(request.getParameter("quantityOfProduct"));
                    
            transactionsManager.orderFromWarehouseToStore(warehouseID,storeID,productID,prodQuantity);
 
                userPath = "StoreInventory";
        }
        else if (request.getParameter("addVendor") != null) {
            Integer vID = Integer.parseInt(request.getParameter("vendorID"));
            String vAddress = request.getParameter("vendorAddress");
            String vName = request.getParameter("vendorName");

            transactionsManager.addVendor(vID,vName, vAddress);
            
            userPath = "Vendor";
        } 

        
        
        
        else if (request.getParameter("empTableRefresh") != null) {
            session.setAttribute("employees", employeesFacades.findAll());
            userPath = "index";
        }
        else if (request.getParameter("warTableRefresh") != null) {
            session.setAttribute("warehouses", warehousesFacades.findAll());
            userPath = "Warehouse";
        }
        else if (request.getParameter("storeTableRefresh") != null) {
            session.setAttribute("stores", storesFacades.findAll());
            userPath = "Store";
        }
        else if (request.getParameter("hireTableRefresh") != null) {
            session.setAttribute("employees", employeesFacades.findAll());
            userPath = "hireEmployee";
        }
        else if (request.getParameter("fireTableRefresh") != null) {
            session.setAttribute("employees", employeesFacades.findAll());
            userPath = "fireEmployee";
        }
        else if (request.getParameter("productTableRefresh") != null) {
            session.setAttribute("product", productsFacades.findAll());
            userPath = "Product";
        }
        else if (request.getParameter("productWareTableRefresh") != null) {
            session.setAttribute("product", productsFacades.findAll());
            userPath = "WarehouseInventory";
        }
        else if (request.getParameter("receiveTableRefresh") != null) {
            session.setAttribute("recievesTable", receivesFacades.findAll());
            userPath = "WarehouseInventory";
        } 
        else if (request.getParameter("storeCarriesTableRefresh") != null) {
            session.setAttribute("storeCarriesTable", carriesFacades.findAll());
            userPath = "StoreInventory";
        }    
        else if (request.getParameter("storeReceiveTableRefresh") != null) {
            session.setAttribute("recievesTable", receivesFacades.findAll());
            userPath = "StoreInventory";
        } 
        else if (request.getParameter("vendorTableRefresh") != null) {
            session.setAttribute("vendors", vendorsFacades.findAll());
            userPath = "Vendor";
        } 
        else if (request.getParameter("vendorSellsTableRefresh") != null) {
            session.setAttribute("sells", sellsFacade.findAll());
            userPath = "VendorInventory";
        }     
         else if (request.getParameter("sellsWareTableRefresh") != null) {
            session.setAttribute("sells", sellsFacade.findAll());
            userPath = "WarehouseInventory";
        }     
        
        
        
       String url = userPath + ".jsp";

        try {
            request.getRequestDispatcher(url).forward(request, response);
        } catch (Exception ex) {
            ex.printStackTrace();
        } 
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
       
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
   

}
