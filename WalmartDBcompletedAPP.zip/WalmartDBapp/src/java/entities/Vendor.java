/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Dillon
 */
@Entity
@Table(name = "vendor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Vendor.findAll", query = "SELECT v FROM Vendor v"),
    @NamedQuery(name = "Vendor.findByVid", query = "SELECT v FROM Vendor v WHERE v.vid = :vid"),
    @NamedQuery(name = "Vendor.findByVname", query = "SELECT v FROM Vendor v WHERE v.vname = :vname"),
    @NamedQuery(name = "Vendor.findByAddress", query = "SELECT v FROM Vendor v WHERE v.address = :address")})
public class Vendor implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vendor")
    private Collection<Sells> sellsCollection;

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "Vid")
    private Integer vid;
    @Size(max = 45)
    @Column(name = "Vname")
    private String vname;
    @Size(max = 45)
    @Column(name = "Address")
    private String address;
    @ManyToMany(mappedBy = "vendorCollection")
    private Collection<Product> productCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "vendor")
    private Collection<Ordersfrom> ordersfromCollection;
    @JoinColumn(name = "PrimaryWarehouse", referencedColumnName = "WarehouseID")
    @ManyToOne
    private Warehouse primaryWarehouse;
    @JoinColumn(name = "ProductsSupplied", referencedColumnName = "Pid")
    @ManyToOne
    private Product productsSupplied;
    @OneToMany(mappedBy = "pvendor")
    private Collection<Store> storeCollection;

    public Vendor() {
    }

    public Vendor(Integer vid) {
        this.vid = vid;
    }

    public Integer getVid() {
        return vid;
    }

    public void setVid(Integer vid) {
        this.vid = vid;
    }

    public String getVname() {
        return vname;
    }

    public void setVname(String vname) {
        this.vname = vname;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @XmlTransient
    public Collection<Product> getProductCollection() {
        return productCollection;
    }

    public void setProductCollection(Collection<Product> productCollection) {
        this.productCollection = productCollection;
    }

    @XmlTransient
    public Collection<Ordersfrom> getOrdersfromCollection() {
        return ordersfromCollection;
    }

    public void setOrdersfromCollection(Collection<Ordersfrom> ordersfromCollection) {
        this.ordersfromCollection = ordersfromCollection;
    }

    public Warehouse getPrimaryWarehouse() {
        return primaryWarehouse;
    }

    public void setPrimaryWarehouse(Warehouse primaryWarehouse) {
        this.primaryWarehouse = primaryWarehouse;
    }

    public Product getProductsSupplied() {
        return productsSupplied;
    }

    public void setProductsSupplied(Product productsSupplied) {
        this.productsSupplied = productsSupplied;
    }

    @XmlTransient
    public Collection<Store> getStoreCollection() {
        return storeCollection;
    }

    public void setStoreCollection(Collection<Store> storeCollection) {
        this.storeCollection = storeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (vid != null ? vid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Vendor)) {
            return false;
        }
        Vendor other = (Vendor) object;
        if ((this.vid == null && other.vid != null) || (this.vid != null && !this.vid.equals(other.vid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Vendor[ vid=" + vid + " ]";
    }

    @XmlTransient
    public Collection<Sells> getSellsCollection() {
        return sellsCollection;
    }

    public void setSellsCollection(Collection<Sells> sellsCollection) {
        this.sellsCollection = sellsCollection;
    }
    
}
