/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Dillon
 */
@Embeddable
public class SuppliesPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "WarehouseIDs")
    private int warehouseIDs;
    @Basic(optional = false)
    @NotNull
    @Column(name = "StoreIDs")
    private int storeIDs;

    public SuppliesPK() {
    }

    public SuppliesPK(int warehouseIDs, int storeIDs) {
        this.warehouseIDs = warehouseIDs;
        this.storeIDs = storeIDs;
    }

    public int getWarehouseIDs() {
        return warehouseIDs;
    }

    public void setWarehouseIDs(int warehouseIDs) {
        this.warehouseIDs = warehouseIDs;
    }

    public int getStoreIDs() {
        return storeIDs;
    }

    public void setStoreIDs(int storeIDs) {
        this.storeIDs = storeIDs;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) warehouseIDs;
        hash += (int) storeIDs;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SuppliesPK)) {
            return false;
        }
        SuppliesPK other = (SuppliesPK) object;
        if (this.warehouseIDs != other.warehouseIDs) {
            return false;
        }
        if (this.storeIDs != other.storeIDs) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.SuppliesPK[ warehouseIDs=" + warehouseIDs + ", storeIDs=" + storeIDs + " ]";
    }
    
}
