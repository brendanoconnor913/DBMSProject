/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dillon
 */
@Entity
@Table(name = "receives")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Receives.findAll", query = "SELECT r FROM Receives r"),
    @NamedQuery(name = "Receives.findByWarehID", query = "SELECT r FROM Receives r WHERE r.receivesPK.warehID = :warehID"),
    @NamedQuery(name = "Receives.findByProID", query = "SELECT r FROM Receives r WHERE r.receivesPK.proID = :proID"),
    @NamedQuery(name = "Receives.findByQuantity", query = "SELECT r FROM Receives r WHERE r.quantity = :quantity")})
public class Receives implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected ReceivesPK receivesPK;
    @Column(name = "Quantity")
    private Integer quantity;
    @JoinColumn(name = "ProID", referencedColumnName = "Pid", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Product product;
    @JoinColumn(name = "WarehID", referencedColumnName = "WarehouseID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Warehouse warehouse;

    public Receives() {
    }

    public Receives(ReceivesPK receivesPK) {
        this.receivesPK = receivesPK;
    }

    public Receives(int warehID, int proID) {
        this.receivesPK = new ReceivesPK(warehID, proID);
    }

    public ReceivesPK getReceivesPK() {
        return receivesPK;
    }

    public void setReceivesPK(ReceivesPK receivesPK) {
        this.receivesPK = receivesPK;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Warehouse getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (receivesPK != null ? receivesPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Receives)) {
            return false;
        }
        Receives other = (Receives) object;
        if ((this.receivesPK == null && other.receivesPK != null) || (this.receivesPK != null && !this.receivesPK.equals(other.receivesPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Receives[ receivesPK=" + receivesPK + " ]";
    }
    
}
