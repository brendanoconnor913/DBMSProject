/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;

/**
 *
 * @author Dillon
 */
@Embeddable
public class SellsPK implements Serializable {

    @Basic(optional = false)
    @NotNull
    @Column(name = "ProductID")
    private int productID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "VenID")
    private int venID;

    public SellsPK() {
    }

    public SellsPK(int productID, int venID) {
        this.productID = productID;
        this.venID = venID;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public int getVenID() {
        return venID;
    }

    public void setVenID(int venID) {
        this.venID = venID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (int) productID;
        hash += (int) venID;
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SellsPK)) {
            return false;
        }
        SellsPK other = (SellsPK) object;
        if (this.productID != other.productID) {
            return false;
        }
        if (this.venID != other.venID) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.SellsPK[ productID=" + productID + ", venID=" + venID + " ]";
    }
    
}
