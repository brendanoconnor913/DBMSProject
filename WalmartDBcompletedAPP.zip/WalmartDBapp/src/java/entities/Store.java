/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import java.util.Collection;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author Dillon
 */
@Entity
@Table(name = "store")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Store.findAll", query = "SELECT s FROM Store s"),
    @NamedQuery(name = "Store.findBySid", query = "SELECT s FROM Store s WHERE s.sid = :sid"),
    @NamedQuery(name = "Store.findByAddress", query = "SELECT s FROM Store s WHERE s.address = :address")})
public class Store implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Column(name = "Sid")
    private Integer sid;
    @Size(max = 45)
    @Column(name = "Address")
    private String address;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "store")
    private Collection<Carries> carriesCollection;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "store")
    private Collection<Supplies> suppliesCollection;
    @JoinColumn(name = "MngSSN", referencedColumnName = "SSN")
    @ManyToOne
    private Employee mngSSN;
    @JoinColumn(name = "Pvendor", referencedColumnName = "Vid")
    @ManyToOne
    private Vendor pvendor;
    @JoinColumn(name = "Pwarehouse", referencedColumnName = "WarehouseID")
    @ManyToOne
    private Warehouse pwarehouse;
    @OneToMany(mappedBy = "storeID")
    private Collection<Employee> employeeCollection;

    public Store() {
    }

    public Store(Integer sid) {
        this.sid = sid;
    }

    public Integer getSid() {
        return sid;
    }

    public void setSid(Integer sid) {
        this.sid = sid;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    @XmlTransient
    public Collection<Carries> getCarriesCollection() {
        return carriesCollection;
    }

    public void setCarriesCollection(Collection<Carries> carriesCollection) {
        this.carriesCollection = carriesCollection;
    }

    @XmlTransient
    public Collection<Supplies> getSuppliesCollection() {
        return suppliesCollection;
    }

    public void setSuppliesCollection(Collection<Supplies> suppliesCollection) {
        this.suppliesCollection = suppliesCollection;
    }

    public Employee getMngSSN() {
        return mngSSN;
    }

    public void setMngSSN(Employee mngSSN) {
        this.mngSSN = mngSSN;
    }

    public Vendor getPvendor() {
        return pvendor;
    }

    public void setPvendor(Vendor pvendor) {
        this.pvendor = pvendor;
    }

    public Warehouse getPwarehouse() {
        return pwarehouse;
    }

    public void setPwarehouse(Warehouse pwarehouse) {
        this.pwarehouse = pwarehouse;
    }

    @XmlTransient
    public Collection<Employee> getEmployeeCollection() {
        return employeeCollection;
    }

    public void setEmployeeCollection(Collection<Employee> employeeCollection) {
        this.employeeCollection = employeeCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sid != null ? sid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Store)) {
            return false;
        }
        Store other = (Store) object;
        if ((this.sid == null && other.sid != null) || (this.sid != null && !this.sid.equals(other.sid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Store[ sid=" + sid + " ]";
    }
    
}
