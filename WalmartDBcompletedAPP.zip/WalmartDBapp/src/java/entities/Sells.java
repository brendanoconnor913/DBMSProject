/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dillon
 */
@Entity
@Table(name = "sells")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Sells.findAll", query = "SELECT s FROM Sells s"),
    @NamedQuery(name = "Sells.findByProductID", query = "SELECT s FROM Sells s WHERE s.sellsPK.productID = :productID"),
    @NamedQuery(name = "Sells.findByVenID", query = "SELECT s FROM Sells s WHERE s.sellsPK.venID = :venID"),
    @NamedQuery(name = "Sells.findByQuantityProd", query = "SELECT s FROM Sells s WHERE s.quantityProd = :quantityProd")})
public class Sells implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected SellsPK sellsPK;
    @Column(name = "QuantityProd")
    private Integer quantityProd;
    @JoinColumn(name = "ProductID", referencedColumnName = "Pid", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Product product;
    @JoinColumn(name = "VenID", referencedColumnName = "Vid", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Vendor vendor;

    public Sells() {
    }

    public Sells(SellsPK sellsPK) {
        this.sellsPK = sellsPK;
    }

    public Sells(int productID, int venID) {
        this.sellsPK = new SellsPK(productID, venID);
    }

    public SellsPK getSellsPK() {
        return sellsPK;
    }

    public void setSellsPK(SellsPK sellsPK) {
        this.sellsPK = sellsPK;
    }

    public Integer getQuantityProd() {
        return quantityProd;
    }

    public void setQuantityProd(Integer quantityProd) {
        this.quantityProd = quantityProd;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Vendor getVendor() {
        return vendor;
    }

    public void setVendor(Vendor vendor) {
        this.vendor = vendor;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (sellsPK != null ? sellsPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Sells)) {
            return false;
        }
        Sells other = (Sells) object;
        if ((this.sellsPK == null && other.sellsPK != null) || (this.sellsPK != null && !this.sellsPK.equals(other.sellsPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Sells[ sellsPK=" + sellsPK + " ]";
    }
    
}
