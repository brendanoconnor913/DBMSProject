/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entities;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author Dillon
 */
@Entity
@Table(name = "supplies")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Supplies.findAll", query = "SELECT s FROM Supplies s"),
    @NamedQuery(name = "Supplies.findByWarehouseIDs", query = "SELECT s FROM Supplies s WHERE s.suppliesPK.warehouseIDs = :warehouseIDs"),
    @NamedQuery(name = "Supplies.findByStoreIDs", query = "SELECT s FROM Supplies s WHERE s.suppliesPK.storeIDs = :storeIDs"),
    @NamedQuery(name = "Supplies.findByQuantity", query = "SELECT s FROM Supplies s WHERE s.quantity = :quantity")})
public class Supplies implements Serializable {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    protected SuppliesPK suppliesPK;
    @Column(name = "Quantity")
    private Integer quantity;
    @JoinColumn(name = "ProdIDnum", referencedColumnName = "Pid")
    @ManyToOne
    private Product prodIDnum;
    @JoinColumn(name = "StoreIDs", referencedColumnName = "Sid", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Store store;
    @JoinColumn(name = "WarehouseIDs", referencedColumnName = "WarehouseID", insertable = false, updatable = false)
    @ManyToOne(optional = false)
    private Warehouse warehouse;

    public Supplies() {
    }

    public Supplies(SuppliesPK suppliesPK) {
        this.suppliesPK = suppliesPK;
    }

    public Supplies(int warehouseIDs, int storeIDs) {
        this.suppliesPK = new SuppliesPK(warehouseIDs, storeIDs);
    }

    public SuppliesPK getSuppliesPK() {
        return suppliesPK;
    }

    public void setSuppliesPK(SuppliesPK suppliesPK) {
        this.suppliesPK = suppliesPK;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public Product getProdIDnum() {
        return prodIDnum;
    }

    public void setProdIDnum(Product prodIDnum) {
        this.prodIDnum = prodIDnum;
    }

    public Store getStore() {
        return store;
    }

    public void setStore(Store store) {
        this.store = store;
    }

    public Warehouse getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (suppliesPK != null ? suppliesPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Supplies)) {
            return false;
        }
        Supplies other = (Supplies) object;
        if ((this.suppliesPK == null && other.suppliesPK != null) || (this.suppliesPK != null && !this.suppliesPK.equals(other.suppliesPK))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entities.Supplies[ suppliesPK=" + suppliesPK + " ]";
    }
    
}
